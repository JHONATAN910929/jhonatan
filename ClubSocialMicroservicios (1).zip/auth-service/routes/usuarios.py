from flask import Blueprint, jsonify
import mysql.connector

usuarios_bp = Blueprint('usuarios', __name__)

@usuarios_bp.route('/usuarios', methods=['GET'])
def listar_usuarios():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="rootpass",
        database="ClubSocial"
    )
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT id, username, rol FROM Usuario")
    usuarios = cursor.fetchall()
    conn.close()
    return jsonify(usuarios)
