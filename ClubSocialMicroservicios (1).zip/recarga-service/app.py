from flask import Flask
from routes.recargas import recargas_bp

app = Flask(__name__)
app.register_blueprint(recargas_bp)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8003)
