async function fetchAndRender(url, containerId) {
    try {
        const res = await fetch(url);
        const data = await res.json();
        const container = document.getElementById(containerId);
        container.innerHTML = '<ul>' + data.map(d => '<li>' + JSON.stringify(d) + '</li>').join('') + '</ul>';
    } catch (err) {
        document.getElementById(containerId).innerText = 'Error cargando datos de ' + url;
    }
}

document.getElementById('app').innerHTML = `
    <h2>Socios</h2><div id="socios"></div>
    <h2>Facturas</h2><div id="facturas"></div>
    <h2>Recargas</h2><div id="recargas"></div>
    <h2>Usuarios</h2><div id="usuarios"></div>
`;

fetchAndRender('http://localhost:8001/socios', 'socios');
fetchAndRender('http://localhost:8002/facturas', 'facturas');
fetchAndRender('http://localhost:8003/recargas', 'recargas');
fetchAndRender('http://localhost:8004/usuarios', 'usuarios');
