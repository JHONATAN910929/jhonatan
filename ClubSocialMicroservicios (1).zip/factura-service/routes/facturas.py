from flask import Blueprint, jsonify
import mysql.connector

facturas_bp = Blueprint('facturas', __name__)

@facturas_bp.route('/facturas', methods=['GET'])
def listar_facturas():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="rootpass",
        database="ClubSocial"
    )
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM Factura")
    facturas = cursor.fetchall()
    conn.close()
    return jsonify(facturas)
