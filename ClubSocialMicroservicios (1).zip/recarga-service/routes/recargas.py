from flask import Blueprint, jsonify
import mysql.connector

recargas_bp = Blueprint('recargas', __name__)

@recargas_bp.route('/recargas', methods=['GET'])
def listar_recargas():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="rootpass",
        database="ClubSocial"
    )
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM Recarga")
    recargas = cursor.fetchall()
    conn.close()
    return jsonify(recargas)
