from flask import Blueprint, jsonify
import mysql.connector

socios_bp = Blueprint('socios', __name__)

@socios_bp.route('/socios', methods=['GET'])
def listar_socios():
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="rootpass",
        database="ClubSocial"
    )
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM Socio")
    socios = cursor.fetchall()
    conn.close()
    return jsonify(socios)
